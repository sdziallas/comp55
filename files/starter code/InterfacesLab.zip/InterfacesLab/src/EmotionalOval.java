import java.awt.Color;

import acm.graphics.GOval;

public class EmotionalOval extends GOval {
	private double speedX;
	private double speedY;
	
	public EmotionalOval(double x, double y, double width, double height) {
		super(x, y, width, height);
		speedX = 0;
		speedY = 0;
	}
	
	public void move() {
		move(speedX, speedY);
	}

	public void beCalm() {
		setFilled(false);
		setColor(Color.black);
	}

	public void beHappy() {
		setFilled(true);
		setFillColor(Color.YELLOW);
		setColor(Color.black);
	}

	public void beAngry() {
		setFilled(true);
		setFillColor(Color.RED);
		setColor(Color.RED);
	}
}
