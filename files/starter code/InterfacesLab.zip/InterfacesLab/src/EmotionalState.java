
public enum EmotionalState {
	CALM, HAPPY, ANGRY;

	public String toString() {
		switch(this) {
			case CALM: return "calm";
			case HAPPY: return "happy";
			case ANGRY: return "angry";
		}
		return "n/a";
	}

	public EmotionalState nextEmotion() {
		switch(this) {
			case CALM: return HAPPY;
			case HAPPY: return ANGRY;
			case ANGRY: return CALM;
		}
		return CALM;
	}

	public void expressEmotion(EmotionalOval being) {
		switch(this) {
			case CALM: 
				being.beCalm();
				break;
			case HAPPY:
				being.beHappy();
				break;
			case ANGRY: 
				being.beAngry();
				break;
		}
	}
}
