import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

import acm.graphics.*;
import acm.program.*;

public class EmotionSimulator extends GraphicsProgram {
	private static final int WINDOW_WIDTH = 800;
	private static final int WINDOW_HEIGHT = 600;
	private static final int SIZE = 200;
	
	private EmotionalState currentEmotion;
	private ArrayList<EmotionalOval> individuals;
	
	public void run() {
		individuals = new ArrayList<EmotionalOval>();
		currentEmotion = EmotionalState.CALM;
		makeCharacters();
		addMouseListeners();
	}
	
	public void makeCharacters() {
		makeOvalCharacter(100, 100, SIZE, SIZE);
	}
	
	private void makeOvalCharacter(int x, int y, int w, int h) {
		EmotionalOval e = new EmotionalOval(x, y, w, h);
		add(e);
		individuals.add(e);
	}

	public void mousePressed(MouseEvent e) {
		advanceEmotion();
		expressNewEmotions();
	}
	
	public void advanceEmotion() {
		currentEmotion = currentEmotion.nextEmotion();
	}
	
	public void expressNewEmotions() {
		for(EmotionalOval i:individuals) {
			currentEmotion.expressEmotion(i);
		}
	}
	
	public void init() {
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	}
	
	public static void main(String[] args) {
		new EmotionSimulator().start();
	}
}
