/**
 * Simple class that represents a row and a column, with simple getters and setters for both
 * @author Osvaldo
 */

public class Space {
	//TODO Put your instance variables here
	
	/**
	 * The constructor that will set up the object to store a row and column
	 * 
	 * @param row
	 * @param col
	 */
	public Space(int row, int col) {
		//TODO: this is the constructor, you'll need to fill this in
	}
	
	public int getRow() {
		//TODO fill in this getter
		return 0;
	}
	
	public int getCol() {
		//TODO fill this in
		return 0;
	}
}
